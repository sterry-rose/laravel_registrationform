<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\newuser;

use DB;
use Illuminate\Support\Facades\Storage;

class formController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('welcome');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name'=>'required|min:3|max:20',
            'email'=>'required|email|unique:newusers|email:rfc,dns',
            'phone'=>'required|numeric|digits:10',
            'title'=>'required|min:3|max:20',
            'image' => 'image|mimes:jpeg,jpg,png,gif',
        ]);

        $image = $request->file('image');
        $new_name = rand() . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('images'), $new_name);
            
        newuser::create([
            'name'=>$request->name,
            'email'=>$request->email,
            'phone' => $request->phone,
            'subject' => $request->title,
            'image' => $new_name,
        ]);
           return back()->with('success', 'Details Submitted successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user=newuser::find($id);
         return response()->json([
            'status'=>200,
            'user'=>$user,
        ]);
    }

    public function list()
    {
       $users=DB::table('newusers')->get();
        return view('home',compact('users'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user=newuser::find($id);
        return response()->json([
            'status'=>200,
            'user'=>$user,
        ]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $id = $request->input('userid');
        // Validation
        $this->validate($request, [
            'name'=>'required|min:3|max:20',
            'email'=>'required|email|email:rfc,dns',
            'phone'=>'required|numeric|digits:10',
            'title'=>'required|min:3|max:20',
            'image' => 'image|mimes:jpeg,jpg,png,gif',
        ]);

        $image = $request->file('image');
        $new_name = rand() . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('images'), $new_name);

        $user=newuser::find($id);
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->phone = $request->input('phone');
        $user->subject = $request->input('title');
        $user->image = $new_name;
       
        $user->save();
        
        //session msg
          return redirect()->back()->with('success', 'Data succesfully updated.!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $id = $request->input('userdelid');
        $user=newuser::find($id);
        $user->delete();
        return redirect()->back()->with('success', 'Data deleted succesfully .!');

    }
}
