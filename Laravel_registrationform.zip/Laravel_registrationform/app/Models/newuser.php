<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class newuser extends Model
{
    use HasFactory;
    protected $guarded=[];
   // protected $table = 'newusers';
   // protected $fillable=['name','email','phone','subject','image'];
}
