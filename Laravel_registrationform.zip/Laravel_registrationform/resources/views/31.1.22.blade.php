<!DOCTYPE html>
<html lang="en">
<head>
<title>Application DB</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Datatables css -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />


<style>
    /* Point-zoom Container */
    .point-img-zoom img {  transform-origin: 65% 75%; 
     transition: transform 1s, filter .5s ease-out;
     }/* The Transformation */
     .point-img-zoom:hover img 
     {  transform: scale(5);}
</style>
</head>
<body>
    <div class="container p-5">
    <table id="table1" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th> # </th>
                <th> Image </th>
                <th> Name </th>
                <th> Email </th>
                <th> Phone No.</th>
                <th> Title</th>
                <th> Application Date</th>
                <th> Actions </th>

            </tr>
        </thead>
        <tbody>
            @foreach($users as $data)
                                <tr>
                                    <td scope="row">{{ $loop->iteration }}</td>
                                    <td> <img class="rounded-circle" src="{{URL::to('/') }}/images/{{$data->image }}" alt="" style="width:70px;">
                                    </td>
                                    <td>{{ $data->name }}</td>
                                    <td>{{ $data->email }}</td>
                                    <td>{{ $data->phone }}</td>
                                    <td>{{ $data->subject }}</td>
                                    <td>{{ $data->created_at}}</td>

                                    <td>
                                       
                                       
                                          <a href="{{ url('forms.show',$data->id) }}" class="btn btn-info" title="View more details">view</a>
                                          <a href="" class="btn btn-warning edit">edit</a>
                                          <div class="btn-group">
                                          @csrf
                                          @method('delete')
                                          <form action="{{ route('forms.destroy',$data->id) }}" method="POST" >
                                         <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure to Delete?')">delete</button>
                                         </form>                             
                                        </div>
                                    </td>
                                </tr>
                                @endforeach

                       
        </tbody>
        <tfoot>
            <tr>
                <th> # </th>
                <th> Image </th>
                <th> Name </th>
                <th> Email </th>
                <th> Phone No.</th>
                <th> Title</th>
                <th> Application Date</th>
                <th> Actions </th>
            </tr>
        </tfoot>

    </table>
</div>

<div id="editModal" class="modal fade">
    <div class="modal-dialog">
     <div class="modal-content">
      <form>
       <div class="modal-header">      
        <h4 class="modal-title">Add Employee</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
       </div>
       <div class="modal-body">     
        <div class="form-group">
         <label>Name</label>
         <input type="text" class="form-control" required>
        </div>
        <div class="form-group">
         <label>Email</label>
         <input type="email" class="form-control" required>
        </div>
        <div class="form-group">
         <label>Address</label>
         <textarea class="form-control" required></textarea>
        </div>
        <div class="form-group">
         <label>Phone</label>
         <input type="text" class="form-control" required>
        </div>     
       </div>
       <div class="modal-footer">
        <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
        <input type="submit" class="btn btn-success" value="Add">
       </div>
      </form>
     </div>
    </div>
   </div>
                                                
    <!-- Datatables js -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js"></script>

<script>
    
    $(document).ready(function() {
   var table= $('#table1').DataTable();

    table.on('click','.edit',function(){

        $('#editModal').modal('show');

    });
} );

</script>
</body>


</html>


