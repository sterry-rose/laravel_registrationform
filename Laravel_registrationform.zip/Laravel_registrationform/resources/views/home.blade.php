<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<title>Application Details</title>

<!-- Datatables css -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />
<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet" type="text/css" />

<style>
    .table-title {        
        padding-bottom: 15px;
        background: linear-gradient(40deg, #2096ff, #05ffa3) !important;
        color: #fff;
        padding: 16px 30px;
        margin: -20px -25px 10px;
        border-radius: 1px 1px 0 0;
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.247);
    }
    .table-title h2 {
        margin: 5px 0 0;
        font-size: 24px;
 }

 .rounded-circle{
        width: 50px;
        height: 50px;
        display:block;
        z-index:999;
        cursor: pointer;
        -webkit-transition-property: all;
        -webkit-transition-duration: 0.3s;
        -webkit-transition-timing-function: ease;
}
.rounded-circle:hover {
    transform: scale(8);
}
</style>
</head>
<body>
  
  <!-- Edit Modal -->
  <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form action="{{ url('update') }}" class="requires-validation" id="editForm" method="POST"   enctype="multipart/form-data" novalidate>
        @csrf            
        @method('PUT')
                <input type="hidden" id="userid" name="userid" >

                <div class="col-md-12 mt-3">
                   <input class="form-control"  type="text" id="name" name="name" placeholder="Full Name" required>
                   <div class="valid-feedback">Name field is valid!</div>
                   <div class="invalid-feedback">Name field cannot be blank!</div>
                </div>

                <div class="col-md-12 mt-3">
                    <input class="form-control" type="email" id="email" name="email" placeholder="E-mail Address" required>
                     <div class="valid-feedback">Email field is valid!</div>
                     <div class="invalid-feedback">Email field cannot be blank!</div>
                </div>
                

               <div class="col-md-12 mt-3">
                  <input class="form-control" type="tel" id="phone"  name="phone" maxlength="10" placeholder="Mobile Number" pattern="[7-9]{1}[0-9]{9}"  required>
                   <div class="valid-feedback">field is valid!</div>
                   <div class="invalid-feedback"> 
                    Phone number with 7-9 and remaing 9 digit with 0-9</div>
               </div>


               <div class="col-md-12 mt-3">
                <input class="form-control" type="text" id="title" name="title" placeholder="Talk Title" required>
                <div class="valid-feedback">Talk Title field is valid!</div>
                <div class="invalid-feedback">Talk Title field cannot be blank!</div>
               </div>


               <div class="col-md-12 mt-3">
                
                <img src='' id="oldimage" width="180px;" height="120" class="mt-2">
                <p>Current Picture</p>

                <label class="form-label" for="customFile">Your profile photo</label>
                <input type="file" class="form-control" id="image" name="image" required/>
                <div class="valid-feedback">profile photo field is valid!</div>
                <div class="invalid-feedback">Upload your photo!</div>
                </div>

        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Update</button>
        </div>
        </form>

      </div>
    </div>
  </div>

  <!-- Edit Model Ends-->

   <!-- Delete Modal -->
   <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form action="{{ url('delete') }}"  id="deleteForm" method="POST">
        @csrf            
        @method('DELETE')
                <input type="hidden" id="userdelid" name="userdelid" >

                <h6>Are you sure to delete data?</h6>

        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <button type="submit" class="btn btn-primary">Yes,Delete</button>
        </div>
        </form>

      </div>
    </div>
  </div>

  <!-- Delete Model Ends-->

    <!-- View Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Applicant Details</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div>
              <p><img src='' id="currentimage" width="380px;" height="250" class="mt-2"></p>

              <p>Name: <input type="text" id="details1" STYLE="border:0" readonly="readonly" /></p>
              <p>Email:<input type="text" id="details2" STYLE="border:0" readonly="readonly" /></p>
              <p>Phone:<input type="text" id="details3" STYLE="border:0" readonly="readonly" /></p>
              <p>Title:<input type="text" id="details4" STYLE="border:0" readonly="readonly" /></p>
   
            </div>
          </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
    
          </div>
        </div>
      </div>
    
      <!-- View Model Ends-->
   
    <div class="container py-5">

        <div class="table-title">
            <div class="row">
                <div class="col-sm-6">
                <h2>Applicant List</h2>
                </div>
            </div>
        </div>

        <div id="app">
            @include('message')
        </div>
             <div class="row">
    <table id="table1" class="table table-striped p-5" style="width:100%">
        <thead>
            <tr>
                <th> # </th>
                <th> Image </th>
                <th> Name </th>
                <th> Email </th>
                <th> Phone No.</th>
                <th> Title</th>
                <th> Application Date</th>
                <th> Actions </th>

            </tr>
        </thead>
        <tbody>
            @foreach($users as $data)
                                <tr>
                                    <td scope="row">{{ $loop->iteration }}</td>
                                    <td> <img class="rounded-circle" src="{{URL::to('/') }}/images/{{$data->image }}" alt="" style="width:70px;">
                                    </td>
                                    <td>{{ $data->name }}</td>
                                    <td>{{ $data->email }}</td>
                                    <td>{{ $data->phone }}</td>
                                    <td>{{ $data->subject }}</td>
                                    <?php
                                        $time = date('d-m-Y', strtotime($data->created_at));
                                    ?>
                                    <td>{{ $time}}</td>

                                    <td>

                                        <button type="button" value={{ $data->id }}  class="btn btn-primary view btn-sm" title="view"><i class="fa fa-eye text-succcess"></i></button>                                  
                                          <button type="button" value={{ $data->id }} class="btn btn-warning edit btn-sm" title="edit"><i class="fa fa-edit"></i></button>
                                          
                                            <button type="button" value={{ $data->id }} class="btn btn-danger  deletebtn btn-sm"><i class="fa fa-trash-o fa-lg"></i></button>
                                    </td>
                                </tr>
                                @endforeach

                       
        </tbody>
        <tfoot>
            <tr>
                <th> # </th>
                <th> Image </th>
                <th> Name </th>
                <th> Email </th>
                <th> Phone No.</th>
                <th> Title</th>
                <th> Application Date</th>
                <th> Actions </th>
            </tr>
        </tfoot>

    </table>
</div>
</div>
                                                
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>      <!-- js for ajax -->

   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <!-- Datatables js -->
    <script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" src="{{ asset('js/script.js') }}"></script>


<script>
    
    $(document).ready(function() {
        var table= $('#table1').DataTable({ responsive: true});

        table.on('click','.deletebtn',function(){
            
            var id=$(this).val();
            $('#deleteModal').modal('show');
            $('#userdelid').val(id);   

            });

            table.on('click','.view',function(){
            
            var id=$(this).val();
            $('#viewModal').modal('show');
            $.ajax({
                type: "GET", 
                url: "/show/"+id,
              
                success: function(response){
                    console.log(response.user.name);
                    $('#details2').val(response.user.email);
                    $('#details3').val(response.user.phone);
                    $('#details4').val(response.user.subject);
                    $('#details1').val(response.user.name);
                    $("#currentimage").attr('src','images/'+response.user.image);
     
                 }
            });
          
            });

        table.on('click','.edit',function(){
            
            var id=$(this).val();
            $('#editModal').modal('show');

            $.ajax({
                type: "GET", 
                url: "/edit/"+id,
                success: function(response){
                    console.log(response);
                    $('#name').val(response.user.name);
                    $('#email').val(response.user.email);
                    $('#phone').val(response.user.phone);
                    $('#title').val(response.user.subject);
                    $("#oldimage").attr('src','images/'+response.user.image);
                    $('#userid').val(id);
                    
           
                 }
            });
           /* $tr=$(this).closest('tr');
                if($($tr).hasClass('child')){
                    $tr=$tr.prev('.parent');
                }

            var data=table.row($tr).data();
            console.log(data);

            var href = $(this).data("href");
             $("#imagemodal img").attr("src",href );
            $("#imagemodal").modal("show");

            $('#name').val(data[2]);
            $('#email').val(data[3]);
            $('#phone').val(data[4]);
            $('#title').val(data[5]);
           // $('#image').val(data[1]);

            $('#editForm').attr('action'+'/forms/'+data[0]);
*/
        });
    } );
</script>

</body>

</html>


