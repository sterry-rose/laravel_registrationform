<!doctype html>
<html>
<head>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">



<title>Register</title>


<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>




<!-- Styles -->

<link href="{{ asset('css/style.css') }}" rel="stylesheet">

</head>
<body>
    <div id="app">
        @include('message')
        @yield('content')
    </div>

    <div class="form-body">
    <div class="row">
   
        <div class="form-holder">
            <div class="form-content">
                <div class="form-items">
                    <h3>Register Today</h3>
                    <p>Fill in the data below.</p>
                    <form class="requires-validation" method="post" action="{{ url('store') }}"  enctype="multipart/form-data" novalidate>
                        @csrf
                        <div class="col-md-12">
                           <input class="form-control"  type="text" name="name" placeholder="Full Name" required>
                           <div class="valid-feedback">Username field is valid!</div>
                           <div class="invalid-feedback">Username field cannot be blank!</div>
                        </div>

                        <div class="col-md-12">
                            <input class="form-control" type="email" name="email" placeholder="E-mail Address" required>
                             <div class="valid-feedback">Email field is valid!</div>
                             <div class="invalid-feedback">Email field cannot be blank!</div>
                        </div>
                        

                       <div class="col-md-12">
                          <input class="form-control" type="tel" name="phone" maxlength="10" placeholder="Mobile Number" pattern="[7-9]{1}[0-9]{9}"  required>
                           <div class="valid-feedback">field is valid!</div>
                           <div class="invalid-feedback"> 
                            Phone number with 7-9 and remaing 9 digit with 0-9</div>
                       </div>


                       <div class="col-md-12">
                        <input class="form-control" type="text" name="title" placeholder="Talk Title" required>
                        <div class="valid-feedback">Talk Title field is valid!</div>
                        <div class="invalid-feedback">Talk Title field cannot be blank!</div>
                       </div>


                       <div class="col-md-12 mt-3">
                        
                        <label class="form-label" for="customFile">Your profile photo</label>
                        <input type="file" class="form-control" id="image" name="image" required/>
                        <div class="valid-feedback">profile photo field is valid!</div>
                        <div class="invalid-feedback">Upload your photo!</div>
                        </div>
            

                        <div class="form-button mt-3">
                            <button id="submit" type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script type="text/javascript" src="{{ asset('js/script.js') }}"></script>

</html>